/*! jQuery UI - v1.12.0 - 2016-07-11
 * http://jqueryui.com
 * Copyright jQuery Foundation and other contributors; Licensed  */
!function (a) {
  "function" == typeof define && define.amd ? define(["../widgets/datepicker"], a) : a(jQuery.datepicker)
}(function (a) {
  return a.regional.lt = {
    closeText: "Uždaryti",
    prevText: "&#x3C;Atgal",
    nextText: "Pirmyn&#x3E;",
    currentText: "Šiandien",
    monthNames: ["Sausis", "Vasaris", "Kovas", "Balandis", "Gegužė", "Birželis", "Liepa", "Rugpjūtis", "Rugsėjis", "Spalis", "Lapkritis", "Gruodis"],
    monthNamesShort: ["Sau", "Vas", "Kov", "Bal", "Geg", "Bir", "Lie", "Rugp", "Rugs", "Spa", "Lap", "Gru"],
    dayNames: ["sekmadienis", "pirmadienis", "antradienis", "trečiadienis", "ketvirtadienis", "penktadienis", "šeštadienis"],
    dayNamesShort: ["sek", "pir", "ant", "tre", "ket", "pen", "šeš"],
    dayNamesMin: ["Se", "Pr", "An", "Tr", "Ke", "Pe", "Še"],
    weekHeader: "SAV",
    dateFormat: "yy-mm-dd",
    firstDay: 1,
    isRTL: !1,
    showMonthAfterYear: !0,
    yearSuffix: ""
  }, a.setDefaults(a.regional.lt), a.regional.lt
});