<?php
/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 14/08/2017
 */

namespace AppBundle\Utils\Security;



use Symfony\Component\Security\Core\Encoder\BCryptPasswordEncoder;

class SecurityUtil {

	public static function canonicalize($string)
	{
		if (null === $string) {
			return null;
		}

		$encoding = mb_detect_encoding($string);
		$result = $encoding
			? mb_convert_case($string, MB_CASE_LOWER, $encoding)
			: mb_convert_case($string, MB_CASE_LOWER);

		return $result;
	}

	public static function encodePassword($password, $salt,$cost) {

		$passwordEncoder = new BCryptPasswordEncoder($cost);

		return $passwordEncoder->encodePassword($password,$salt);

	}


} 