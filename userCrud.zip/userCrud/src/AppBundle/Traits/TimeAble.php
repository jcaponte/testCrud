<?php
/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 14/08/2017
 * Time: 09:09 PM
 */

namespace AppBundle\Traits;

use Doctrine\ORM\Mapping as ORM;

trait TimeAble {


	/**
	 * @var integer
	 *
	 * @ORM\Column(name="created_by", type="integer", length=11, nullable=true)
	 */
	protected $createdBy;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="updated_by", type="integer", nullable=true)
	 */
	protected $updatedBy;


	/**
	 * @var \DateTime
	 *
	 * @ORM\Column(name="created_at", type="datetime", nullable=true)
	 */
	protected $createdAt;


	/**
	 * @var \DateTime
	 *
	 * @ORM\Column(name="updated_at", type="datetime", nullable=true)
	 */
	protected $updatedAt;

	/**
	 * @ORM\PrePersist()
	 */
	public function preCreatedAt()
	{
		$this->createdAt= new \DateTime();
	}

	/**
	 * @ORM\PreUpdate()
	 */
	public function preUpdatedAt()
	{
		$this->updatedAt= new \DateTime();
	}


	/**
	 * @ORM\PrePersist()
	 */
	public function preCreatedBy()
	{
		$this->createdBy = $GLOBALS['kernel']->getContainer()->get('security.token_storage')->getToken()->getUser()->getUserId();
	}

	/**
	 * @ORM\PreUpdate()
	 */
	public function preUpdatedBy()
	{
		$this->updatedBy = $GLOBALS['kernel']->getContainer()->get('security.token_storage')->getToken()->getUser()->getUserId();
	}


}