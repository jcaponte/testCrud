<?php

namespace AppBundle\Form;

use AppBundle\Entity\User;
use AppBundle\Enum\StatusTypeEnum;
use AppBundle\Form\CountryType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class UserType extends AbstractType {

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
          ->add( 'firstName', TextType::class,
            array(
              'label' => 'Nombre: ',
              'required' => 'true'
            ))
          ->add( 'lastName', TextType::class,
            array(
              'label' => 'Apellido: ',
              'required' => 'true'
            ))
	        ->add('email',EmailType::class,
		        array(
			        'label' => 'Correo Electrónico: ',
			        'required' => true
		        )
	        )
	        ->add( 'password', RepeatedType::class, array(
		        'type'            => PasswordType::class,
		        'invalid_message' => 'Las claves son diferentes.',
		        'options'         => array( 'attr' => array( 'class' => 'password' ) ),
		        'required'        => true,
		        'first_options'   => array( 'label' => 'Clave: ' ),
		        'second_options'  => array( 'label' => 'Confirmar Clave: ' ),
	        ))
	        ->add( 'status', ChoiceType::class,
		        array(
			        'choices' => StatusTypeEnum::getAllStatus(),
			        'choice_label' => function($status, $key, $index) {
				        return $status;
			        },
			        'label'=> 'Status: ',
			        'required'     => true
		        ) )
	        ->add( 'country', CountryType::class,
		        array(
			        'label' => 'País: ',
			        'required' => 'true'
		        ))
	        ->add( 'role', RoleType::class,
		        array(
			        'label' => 'Rol: ',
			        'required' => 'true'
		        ))
        ;

    }
    
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => User::class,
            'cascade_validation' => true,
        ));
    }
  public function getName()
  {
    return 'user';
  }
}
