<?php

namespace AppBundle\Form;

use AppBundle\Entity\Role;
use AppBundle\Enum\StatusTypeEnum;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RoleType extends AbstractType {

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {

	    $systemRoles = [
		    'ROLE_ADMIN'        => 'Administrador',
		    'ROLE_EDIT'         => 'Editor',
		    'ROLE_AUTHOR'       => 'Autor',
		    'ROLE_CONTRIBUTOR'  => 'Colaborador',
		    'ROLE_SUBSCRIBER'   => 'Suscriptor'
	    ];

        $builder
	        ->add( 'name', ChoiceType::class,
		        array(
			        'choices' => $systemRoles,
			        'choice_label' => function($roles, $key, $index) {
				        return $roles;
			        },
			        'label'=> 'Roles: ',
			        'required'     => true
		        ) )
          ->add( 'Description', TextType::class,
            array(
              'label' => 'Descripción: ',
              'required' => 'true'
            ))
	        ->add( 'status', ChoiceType::class,
		        array(
			        'choices' => array('Activo' =>1,'Inactivo' =>0),
			        'choice_label' => function($status, $key, $index) {
				        return $key;
			        },
			        'label'=> 'Status: ',
			        'required'     => true
		        ) )
        ;

    }
    
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => Role::class,
            'cascade_validation' => true,
        ));
    }
  public function getName()
  {
    return 'role';
  }
}
