<?php

namespace AppBundle\Form;

use AppBundle\Entity\Country;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CountryType extends AbstractType {

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
	    $countryArray =
		    [
			    'Argentina',
			    'Bolívia',
			    'Brasil',
			    'Chile',
			    'Colombia',
			    'Costa Rica',
			    'Ecuador',
			    'Guatemala',
			    'Haití',
			    'Nicaragüa',
			    'México',
			    'Perú',
			    'República Dominicana',
			    'Urugüay',
			    'USA',
			    'Venezuela'];

        $builder
	        ->add( 'name', ChoiceType::class,
		        array(
			        'choices' => $countryArray,
			        'choice_label' => function($countries, $key, $index) {
				        return $countries;
			        },
			        'label'=> 'País: ',
			        'required'     => true
		        ) )
          ->add( 'phonePrefix', TextType::class,
            array(
              'label' => 'Prefijo Telefónico: ',
              'required' => 'true'
            ));

    }
    
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => Country::class,
            'cascade_validation' => true,
        ));
    }
  public function getName()
  {
    return 'country';
  }
}
