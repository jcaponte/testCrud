<?php

/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 14/08/2017
 * Time: 1:50 PM
 */


namespace AppBundle\Entity;

use AppBundle\Traits\TimeAble;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\JoinColumn;
use Doctrine\ORM\Mapping\JoinTable;

/**
 * Country
 * @ORM\Entity
 * @ORM\Table(name="country")
 */
class Country
{


	/**
	 * @var integer
	 *
	 * @ORM\Column(name="country_id", type="integer", length=11)
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	private $countryId;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=45, nullable=true)
     */
    private $name;


	/**
	 * @var string
	 *
	 * @ORM\Column(name="phone_prefix", type="string", length=45, nullable=true)
	 */
	private $phonePrefix;


	/**
	 * @ORM\OneToMany(targetEntity="\AppBundle\Entity\User", mappedBy="country")
	 * @JoinTable(name="user_country",
	 *      joinColumns={@JoinColumn(name="country_id", referencedColumnName="country_id")},
	 *      inverseJoinColumns={@JoinColumn(name="country_id", referencedColumnName="country_id")}
	 *      )
	 */

	private $users;

	public function __construct() {
		$this->users = new ArrayCollection();
	}


	public function toArray() {
		return array(
			'id'  => $this->countryId,
		 'name' => $this->name
	 );
	}


	public function toJson() {
		return json_encode($this->toArray());
	}

		public function __toString() {
		return $this->getName();
	}

	/**
	 * @return string
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * @param string $name
	 */
	public function setName( $name ) {
		$this->name = $name;
	}

	/**
	 * @return mixed
	 */
	public function getUsers() {
		return $this->users;
	}

	/**
	 * @param mixed $users
	 */
	public function setUser( $users ) {
		$this->users = $users;
	}

	/**
	 * @return int
	 */
	public function getCountryId() {
		return $this->countryId;
	}


	/**
	 * @return string
	 */
	public function getPhonePrefix() {
		return $this->phonePrefix;
	}

	/**
	 * @param string $phonePrefix
	 */
	public function setPhonePrefix( $phonePrefix ) {
		$this->phonePrefix = $phonePrefix;
	}



}

