<?php
/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 14/08/2017
 * Time: 2:00 PM
 */

namespace AppBundle\Entity;


use AppBundle\Enum\StatusTypeEnum;
use AppBundle\Traits\TimeAble;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\JoinColumn;
use Doctrine\ORM\Mapping\ManyToOne;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints as Assert;

use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\EquatableInterface;

/**
 * @ORM\Entity
 * @ORM\Table(name="user")
 * @ORM\HasLifecycleCallbacks
 * @UniqueEntity("email",
 *   message="Este correo ya existe!")
 */
class User implements UserInterface, EquatableInterface, \Serializable
{

	use TimeAble;

	/**
	 * @var integer
	 * @ORM\Id
	 * @ORM\Column(name="user_id", type="integer")
	 * @ORM\GeneratedValue(strategy="IDENTITY")
	 */
	private $userId;

	/**
	 * @var string
	 * @Assert\NotBlank()
	 * @ORM\Column(name="first_name", type="string", length=64, nullable=true)
	 */
	private $firstName;

	/**
	 * @var string
	 * @Assert\NotBlank()
	 * @ORM\Column(name="last_name", type="string", length=64, nullable=true)
	 */
	private $lastName;

	/**
	 * message = "Este correo '{{ value }}' no es válido.",
	 * checkMX = true
	 * @var string
	 * @Assert\Email(
	 *     message = "Este correo '{{ value }}' no es válido."
	 * )
	 * @ORM\Column(name="email", type="string", length=64, nullable=false,unique=true)
	 */

	private $email ;

	/**
	 * @var string
	 * @Assert\NotBlank()
	 * @ORM\Column(name="password", type="string", length=72, nullable=false)
	 */
	private $password ;

	/**
	 * @var string
	 * @ORM\Column(name="status", type="string", nullable=false,options={"default"=0})
	 */

	private $status;

	/**
	 * @ManyToOne(targetEntity="AppBundle\Entity\Country", inversedBy="users", cascade={"persist"})
	 * @JoinColumn(name="country_id", referencedColumnName="country_id",nullable=true)
	 */

	private $country;


	/**
	 * @ManyToOne(targetEntity="AppBundle\Entity\Role", inversedBy="users",cascade={"persist"})
	 * @JoinColumn(name="user_role_id", referencedColumnName="user_role_id",nullable=true)
	 */

	private $role;

	private $systemRoles = [
	'Administrador' => 'ROLE_ADMIN',
	'Editor'        => 'ROLE_EDIT',
	'Autor'         => 'ROLE_AUTHOR',
	'Colaborador'   => 'ROLE_CONTRIBUTOR',
	'Suscriptor'    => 'ROLE_SUBSCRIBER'
];


	/**
	 * @return int
	 */
	public function getUserId() {
		return $this->userId;
	}

	/**
	 * @param int $userId
	 */
	public function setUserId( $userId ) {
		$this->userId = $userId;
	}

	/**
	 * @return string
	 */
	public function getFirstName() {
		return $this->firstName;
	}

	/**
	 * @param string $firstName
	 */
	public function setFirstName( $firstName ) {
		$this->firstName = $firstName;
	}

	/**
	 * @return string
	 */
	public function getLastName() {
		return $this->lastName;
	}

	/**
	 * @param string $lastName
	 */
	public function setLastName( $lastName ) {
		$this->lastName = $lastName;
	}

	/**
	 * @return string
	 */
	public function getEmail() {
		return $this->email;
	}

	/**
	 * @param string $email
	 */
	public function setEmail( $email ) {
		$this->email = $email;
	}

	/**
	 * @return string
	 */
	public function getPassword() {
		return $this->password;
	}

	/**
	 * @param string $password
	 */
	public function setPassword( $password ) {
		$this->password = $password;
	}


	/**
	 * @param string $status
	 * @return User
	 */
	public function setStatus($status)
	{
		if (!in_array($status, StatusTypeEnum::getAllStatus())) {
			throw new \InvalidArgumentException("Estado Inválido");
		}
		$this->status = $status;
		return $this;
	}

	/**
	 * @return mixed
	 */
	public function getStatus() {
		return $this->status;
	}



	/**
	 * @return mixed
	 */
	public function getCountry() {
		return $this->country;
	}

	/**
	 * @param mixed $country
	 */
	public function setCountry( $country ) {
		$this->country = $country;
	}


	/**
	 * User constructor.
	 */
	public function __construct() {
	}

	public function __toString() {
		return $this->getEmail();
	}


	/**
	 *
	 * @param UserInterface $user
	 *
	 * @return bool
	 */
	public function isEqualTo( UserInterface $user ) {

		if (!$user instanceof UserInterface) {
			return false;
		}

		if ($this->password !== $user->getPassword()) {
			return false;
		}
		return true;

	}

	/**
	 *
	 * @return null
	 */
	public function getSalt() {
		return null;
	}

	/**
	 * Returns the username used to authenticate the user.
	 *
	 * @return string The username
	 */
	public function getUsername() {
		return $this->email;
	}


	/**
	 * @param mixed $userName
	 */
	public function setUserName( $userName ) {
		$this->email = $userName;
	}


	/**
	 * @return mixed
	 */
	public function getRole() {
		return $this->role;
	}

	/**
	 * @param mixed $role
	 */
	public function setRole( $role ) {
		$this->role = $role;
	}


	/**
	 * Returns the role granted to the user.
	 **
	 * @return (Role|string)[] The user role
	 */
	public function getRoles() {
		return array($this->systemRoles[$this->getRole()->getName()]);
	}


	/**
	 * Removes sensitive data from the user.
	 *
	 * This is important if, at any given point, sensitive information like
	 * the plain-text password is stored on this object.
	 */
	public function eraseCredentials() {
		$this->setPassword('');
	}

		/**
	 * String representation of object
	 * @link http://php.net/manual/en/serializable.serialize.php
	 * @return string the string representation of the object or null
	 * @since 5.1.0
	 */
	public function serialize() {
		return serialize(array(
			$this->userId,
			$this->email,
			$this->password
		));
	}

	/**
	 * Constructs the object
	 * @link http://php.net/manual/en/serializable.unserialize.php
	 *
	 * @param string $serialized <p>
	 * The string representation of the object.
	 * </p>
	 *
	 * @return void
	 * @since 5.1.0
	 */
	public function unserialize( $serialized ) {
		list (
			$this->userId,
			$this->email,
			$this->password
			) = unserialize($serialized);
}

	public function toArray() {
		return [
			'id' =>$this->getUserId(),
			'firstName' =>$this->getFirstName(),
			'lastName' =>$this->getLastName(),
			'email' =>$this->getEmail(),
			'status' =>$this->getStatus(),
			'country' =>$this->getCountry()->getName(),
			'role' =>$this->getRole()->getName(),
		];
	}
}

