<?php

namespace AppBundle\Entity;

use AppBundle\Enum\StatusTypeEnum;
use AppBundle\Traits\TimeAble;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\JoinColumn;
use Doctrine\ORM\Mapping\JoinTable;
use Doctrine\ORM\Mapping\ManyToOne;

/**
 * Role
 *
 * @ORM\Table(name="user_role")
 * @ORM\Entity
 * @ORM\HasLifecycleCallbacks
 */
class Role
{
	use TimeAble;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="user_role_id", type="integer", length=11)
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	protected $userRoleId;

  /**
   * @var string
   *
   * @ORM\Column(name="name", type="string", length=64, nullable=false)
   */
    protected $name;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="description", type="string", length=512, nullable=true)
	 */
	protected $description;


	/**
	 * @var int
	 *
	 * @ORM\Column(name="active", type="smallint", nullable=false, options={"default"=0})
	 */
	protected $status;


	/**
	 * @ORM\OneToMany(targetEntity="\AppBundle\Entity\User", mappedBy="role")
	 * @JoinTable(name="user_country",
	 *      joinColumns={@JoinColumn(name="user_role_id", referencedColumnName="user_role_id")},
	 *      inverseJoinColumns={@JoinColumn(name="user_role_id", referencedColumnName="user_role_id")}
	 *      )
	 */

	private $users;


	/**
	 * @return int
	 */
	public function getUserRoleId() {
		return $this->userRoleId;
	}



	/**
	 * @return mixed
	 */
	public function getUsers() {
		return $this->users;
	}

	/**
	 * @return string
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * @param string $name
	 */
	public function setName( $name ) {
		$this->name = $name;
	}

	/**
	 * @return string
	 */
	public function getDescription() {
		return $this->description;
	}

	/**
	 * @param string $description
	 */
	public function setDescription( $description ) {
		$this->description = $description;
	}

	/**
	 * @return mixed
	 */
	public function getStatus() {
		return $this->status;
	}

	/**
	 * @param string $status
	 * @return Role
	 */
	public function setStatus($status)
	{

		$this->status = $status;
		return $this;
	}


	public function __construct() {
		$this->users = new ArrayCollection();
	}


	public function toArray() {
		return array(
		 'id' => $this->userRoleId,
		 'name' => $this->name,
		 'description' => $this->description
	 );
	}

	public function toJson() {
		return json_encode($this->toArray());
	}

		public function __toString() {
		return $this->name;
	}

}

