<?php
/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 14/05/2017
 * Time: 04:11 PM
 */

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;

/**
 * Print  controller.
 * @Route("/print")
 * @package AppBundle\Controller
 */

class PrintController {


	/**
	 * print a pdf document.
	 *
	 * @param Request $request
	 *
	 * @Route("/pdf/all", name="pint_pdf_all", options={"expose"=true}))
	 * @Method("GET")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse
	 */
	public function printPDFAction( Request $request ) {

		$pdf = $this->get( "white_october.tcpdf" )->create( PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false );


	}


}