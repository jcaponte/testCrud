<?php
/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 14/05/2017
 * Time: 05:11 PM
 */

namespace  AppBundle\Controller;


use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;


/**
 * Error  controller.
 * @Route("/error")
 * @package  AppBundle\Controller
 */
class ErrorController extends Controller {


	protected $configErrorArray = array
	(
		0 => array(
			'class'   => 'info',
			'title'   => 'Error de Configuración',
			'module'  => 'Módulo Productos',
			'message' => ''
		),

	);

	protected $validationErrorArray = array
	(
		0 => array(
			'class'   => 'info',
			'title'   => 'Error de Validación',
			'module'  => 'Módulo Productos',
			'message' => ''
		),

	);

	protected $generalErrorArray = array
	(
		0 => array(
			'class'   => 'info',
			'title'   => 'Error General del Sistema',
			'module'  => 'Módulo Productos',
			'message' => 'Se ha producido un error al tratar realizar la operación'
		),
	);

	protected $securityErrorArray = array
	(
		0 => array(
			'class'   => 'danger',
			'title'   => 'INFORMACIÓN DE SEGURIDAD / MÉTODO DE ACCESO NO PERMITIDO',
			'module'  => 'SEGURIDAD',
			'message' => 'Se ha detectado un acceso no permitido!'
		)
	);


	/**
	 * config error Controller.
	 *
	 * @param Request $request
	 *
	 * @Route("/config/{error-id}", name="config_error" ,  options={"expose"=true})
	 * @Method({"GET", "POST"})
	 * @Security("has_role('ROLE_USER')")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function configErrorAction( Request $request ) {

        return $this->render('error/error.html.twig',
            array(
	            'data' => $this->configErrorArray[ $request->get( 'error-id' ) ]
            )
        );

    }

	/**
	 * validation Error Controller.
	 *
	 * @param Request $request
	 *
	 * @Route("/validation/{error-id}", name="validation_error" ,  options={"expose"=true})
	 * @Method({"GET", "POST"})
	 * @Security("has_role('ROLE_USER')")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function validationErrorAction( Request $request ) {


		return $this->render('error/error.html.twig',
			array(
				'data' => $this->validationErrorArray[ $request->get( 'error-id' ) ],
				'extra' =>$request->get( 'message' )
			)
		);

	}

	/**
	 * general error Controller.
	 *
	 * @param Request $request
	 *
	 * @Route("/general/{error-id}", name="general_error" ,  options={"expose"=true})
	 * @Method({"GET", "POST"})
	 * @Security("has_role('ROLE_USER')")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function generalErrorAction( Request $request ) {

		return $this->render('error/error.html.twig',
			array(
				'data' => $this->generalErrorArray[ $request->get( 'error-id' ) ]
			)
		);

	}

	/**
	 * Security error Controller.
	 *
	 * @param Request $request
	 *
	 * @Route("/security/{error-id}", name="security_error" ,  options={"expose"=true})
	 * @Method({"GET", "POST"})
	 * @Security("has_role('ROLE_USER')")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function securityErrorAction( Request $request ) {

		return $this->render('error/error.html.twig',
			array(
				'data' => $this->generalErrorArray[ $request->get( 'error-id' ) ]
			)
		);

	}


}