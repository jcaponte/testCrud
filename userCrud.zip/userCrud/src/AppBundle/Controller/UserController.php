<?php
/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 14/08/2017
 * Time: 12:50 PM
 */

namespace AppBundle\Controller;

use AppBundle\Entity\User;
use AppBundle\Utils\Security\SecurityUtil;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\Tools\Pagination\Paginator;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Component\HttpFoundation\Response;

use Symfony\Component\HttpFoundation\ResponseHeaderBag;


/**
 * User  controller.
 * @Route("/user")
 * @package AppBundle\Controller
 */


class UserController extends Controller
{

	/**
	 * Show a list of all users.
	 *
	 * @Route("/", name="user_list" ,  options={"expose"=true})
	 * @Method("GET")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function indexAction() {

	$em = $this->getDoctrine()->getManager();

	$users = $em->getRepository('AppBundle:User')->findAll();

		$data = array();

		foreach($users as $index => $user) {
			$data[$index] = $user->toArray();
		}
		$dataArray = array
		( 'status'         => true,
		  'message'        => 'Ok',
		  'items'       => $data,
		);


		return $this->render( ':User:index.html.twig', array(
			'data' => $dataArray,
			'render' =>$this->renderIf(),
		) );

	}

	/**
	 * send an ajax list for datatable search.
	 *
	 * @Route("/", name="user_list_ajax" ,  options={"expose"=true})
	 * @Method("GET")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function ajaxListAction(Request $request) {

		$em = $this->getDoctrine()->getManager();

		$draw = $request->get('draw');
		$length = $request->get('length');
		$start = $request->get('start');
		$columns = $request->get('columns');
		$order = $request->get('order');
		$search = $request->get('search');
		$search = $search['value'];

		if($columns[$order[0]['column']]['data']=='firstName') {
			$columnTitle = 'u.firstName';
		}elseif($columns[$order[0]['column']]['data']=='lastName'){
			$columnTitle = 'u.lastName';
		}elseif($columns[$order[0]['column']]['data']=='email'){
			$columnTitle = 'u.email';
		}else{
			$columnTitle = 'u.firstName';
		}
		$columnOrder = $order[0]['dir'];
		if ($start == 0) {
			$start = 1;
		} else {
			$start = ($start / $length) + 1;
		}
		if ($search) {
			$dql = "SELECT
                    u,
                    r,
                    c,
                  FROM
                    AppBundle:User AS u
                    JOIN u.role AS r
                    JOIN u.country AS c
                  WHERE
                    (u.firtName LIKE '%$search%' OR u.lastName LIKE '%$search%' OR u.email LIKE '%$search%' OR u.role LIKE '%$search%') AND
                  ORDER BY
                    $columnTitle $columnOrder
            ";
		} else {
			$dql = "SELECT
                    u
                  FROM
                    AppBundle:User AS u
                  ORDER BY
                    $columnTitle $columnOrder";
		}
		$query = $em->createQuery($dql)
		            ->setFirstResult($length * ($start - 1))->setMaxResults($length);
		$paginator = new Paginator($query, $fetchJoinCollection = true);
		$arrayResult['recordsTotal'] = count($paginator);
		$arrayResult['recordsFiltered'] = count($paginator);
		$arrayResult['draw'] = $draw;
		$arrayResult['length'] = $length;
		$users = $paginator->getQuery()->getResult();


		$data = array();

		foreach($users as $index => $user) {
			$data[$index] = $user->toArray();
		}
		$dataArray = array
		( 'status'         => true,
		  'message'        => 'Ok',
		  'items'       => $data,
		);

		return new JsonResponse($dataArray);

	}



	/**
	 * edit an user.
	 *
	 * @param Request $request
	 * @param User $user
	 *
	 * @Route("/edit/{id}", name="user_edit" ,  options={"expose"=true})
	 * @Method({"POST","GET"})
	 * @Security("has_role('ROLE_ADMIN')")
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function editAction(Request $request, User $user) {


		$em      = $this->getDoctrine()->getEntityManager();
		$user = $em->getRepository( 'AppBundle:User' )->find( $user );

		$deleteForm = $this->createDeleteForm($user);
		$editForm = $this->createForm('AppBundle\Form\UserType', $user);

		$editForm->handleRequest($request);

		if ($editForm->isSubmitted() && $editForm->isValid()) {

			$em->persist($user);
			$em->flush();
			return $this->redirectToRoute('user_show', array('id' => $user->getUserId()));
		}

		return $this->render('User/edit.html.twig', array(
			'entity' => $user,
			'render' =>$this->renderIf(),
			'edit_form' => $editForm->createView(),
			'delete_form' => $deleteForm->createView(),
		));
	}


	/**
	 * Show a user details.
	 *
	 * @param User $user
	 *
	 * @Route("/show/{id}", name="user_show" ,  options={"expose"=true})
	 * @Method("GET")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function showAction(User $user) {

		$deleteForm = $this->createDeleteForm($user);

		return $this->render(':User:show.html.twig', array(
			'entity' => $user,
			'render' =>$this->renderIf(),
			'delete_form' => $deleteForm->createView(),
		));

	}


	/**
	 * Delete an user.
	 *
	 * @param User $user
	 *
	 * @Route("/delete/{id}", name="user_delete" ,  options={"expose"=true})
	 * @Method({"POST","DELETE"})
	 * @Security("has_role('ROLE_ADMIN')")
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function deleteAction(User $user) {

		$status = true;
		$message = 'El usuario ha sido Eliminado!';

		$em      = $this->getDoctrine()->getEntityManager();


		try {
			$em->remove($user);
			$em->flush();
		} catch (\Exception $e){
			$status = false;
			$message = 'Problemas al intentar eliminar el usuario'." Error Code: ".$e->getCode()." Message: ".$e->getMessage();
		}

		return $this->renderResponse($status,$message,$em,null,'POST');

	}

	/**
	 * Create a new User.
	 *
	 * @param Request $request
	 *
	 * @Route("/new", name="user_new" ,  options={"expose"=true})
	 * @Method({"POST","GET"})
	 * @Security("has_role('ROLE_ADMIN')")
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
	 */
	public function newAction(Request $request) {

		$em      = $this->getDoctrine()->getEntityManager();
		$user = new User();

		$countryCodes=
			[
				'Argentina' =>'501',
				'Bolívia' =>'502',
				'Brasil' =>'503',
				'Chile' =>'504',
				'Colombia' =>'505',
				'Costa Rica' =>'506',
				'Ecuador' =>'507',
				'Guatemala' =>'508',
				'Haití' =>'509',
				'Nicaragüa' =>'510',
				'México' =>'511',
				'Perú' =>'512',
				'República Dominicana' =>'513',
				'Urugüay' =>'514',
				'USA' =>'515',
				'Venezuela','516'];


		$form = $this->createForm('AppBundle\Form\UserType', $user);
		$form->handleRequest($request);

		$deleteForm = $this->createDeleteForm($user);


		if ($form->isSubmitted() && $form->isValid()) {
			$user->setPassword(SecurityUtil::encodePassword( $user->getPassword(), $user->getSalt(), 5 ) );
			$em->persist($user);
			$em->flush();
			return $this->redirectToRoute('user_show', array('id' => $user->getUserId()));
		}

		return $this->render('User/edit.html.twig', array(
			'entity' => $user,
			'render' =>$this->renderIf(),
			'edit_form' => $form->createView(),
			'delete_form' => $deleteForm->createView(),
		));

	}

	/**
	 * Print a user list in a pdf format.
	 *
	 * @Route("/print/pdf", name="user_print_all", options={"expose"=true}))
	 * @Method("GET")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse
	 */
	public function printAllAction() {

		$pdf = $this->get( "white_october.tcpdf" )->create( PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false );

		$this->settingPDFEnvironment($pdf);

		// add a page
		$pdf->AddPage();

		$pdf->Write( 2, 'Lista de Usuarios', '', 0, 'C', true, 0, false, false, 0 );
		$pdf->ln( 5 );
		$pdf->SetFont( 'helvetica', '', 8 );


		$em = $this->getDoctrine()->getEntityManager();
		$users = $em->getRepository( 'AppBundle:User' )  ->findAll();

		$usersList = '
			<table border="1" cellpadding="2"  cellspacing="0">
      	<thead>
					<tr>
						<th colspan="3" style= "background-color: #3DAAE9;color: #FFF;font-weight: bold;text-align: center;">LISTADO DE USUARIOS</th>
					</tr>
          <tr>
            <th width="2%">#</th>
            <th width="30%">Nombre</th>
            <th width="18%">E-Mail</th>
            <th width="15%">Status</th>
            <th width="20%">País</th>
            <th width="15%">Rol</th>
          </tr>
         </thead>
        <tbody>
             ';


		foreach($users as $index => $user) {

			$firstName = $user->getFirstName();
			$lastName = $user->getLastName();
			$userName = $firstName.' '.$lastName;
			$usersList .=
				'<tr>'
				.'<td width="2%">'.$index.'</td>'
				.'<td width="30%">'.$userName.'</td>'
				.'<td width="18%">'.$user->getEmail().'</td>'
				.'<td width="15%">'.$user->getStatus().'</td>'
				.'<td width="20%">'.$user->getCountry().'</td>'
				.'<td width="15%">'.$user->getRole().'</td>'
				.'</tr>';



		}
		$usersList .=
			'</tbody>
    	</table>';


		$pdf->SetFont( 'helvetica', '', 10 );
		$pdf->writeHTML( $usersList, true, false, true, false, '' );

		$today = date('d_m_y_i_s');
		$filename = 'Listado_de_usuarios_'.$today;

		return $pdf->Output( $filename . ".pdf", 'I' ); // This will output the PDF as a response directly;
	}

	/**
	 * Print a user detail in a pdf format.
	 *
	 * @param User $user
	 *
	 * @Route("/print/pdf/{id}", name="user_pdf", options={"expose"=true}))
	 * @Method("GET")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse
	 */
	public function pdfAction(User $user ) {

		$pdf = $this->get( "white_october.tcpdf" )->create( PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false );

		$this->settingPDFEnvironment($pdf);


		// add a page
		$pdf->AddPage();

		$firstName = $user->getFirstName();
		$lastName = $user->getLastName();

		$userName = 'Detalles de '.$firstName.' '.$lastName;

		$pdf->Write( 2, $userName, '', 0, 'C', true, 0, false, false, 0 );
		$pdf->ln( 5 );
		$pdf->SetFont( 'helvetica', '', 8 );


		$userList = '
			<table border="1" cellpadding="2"  cellspacing="0">
      	<thead>
					<tr>
						<th colspan="6" style= "background-color: #3DAAE9;color: #FFF;font-weight: bold;text-align: center;">Detalles</th>
					</tr>
          <tr>
            <th width="20%">Nombre</th>
            <th width="20%">Apellido</th>
            <th width="20%">email</th>
            <th width="10%">status</th>
            <th width="15%">país</th>
            <th width="15%">rol</th>
          </tr>
         </thead>
        <tbody>
             ';

			$userList.=
				'<tr>'
				.'<td width="20%">'.$firstName.'</td>'
				.'<td width="20%">'.$lastName.'</td>'
				.'<td width="20%">'.$user->getEmail().'</td>'
				.'<td width="10%">'.$user->getStatus().'</td>'
				.'<td width="15%">'.$user->getCountry().'</td>'
				.'<td width="15%">'.$user->getRole().'</td>'
				.'</tr>';

		$userList .=
			'</tbody>
    	</table>';

		$pdf->SetFont( 'helvetica', '', 10 );
		$pdf->writeHTML( $userList, true, false, true, false, '' );

		$today = date('d_m_y_i_s');
		$filename = 'detalles_'.$user->getUserId().'_'.$today;

		return $pdf->Output( $filename.'_'.$today. '.pdf', 'I' ); // This will output the PDF as a response directly;
	}

	/**
	 * Print a user detail in an excel format
	 *
	 * @Route("/print/excel", name="user_excel_all", options={"expose"=true}))
	 * @Method("GET")
	 *
	 * @return \Symfony\Component\HttpFoundation\RedirectResponse
	 */
	public function excelAction() {

		$phpExcelObject = $this->get("phpexcel")->createPHPExcelObject();

		$phpExcelObject->getProperties()->setCreator("Juan Carlos Aponte")
		               ->setLastModifiedBy("Juan Carlos Aponte")
		               ->setTitle("Listado de Usuarios")
		               ->setSubject("Usuarios en el sistema")
		               ->setDescription("Creación de documentos en excel usando symfony 3")
		               ->setKeywords("office 2005 openxml php")
		               ->setCategory("Test");

		$phpExcelObject->setActiveSheetIndex(0)
					->setCellValue('A1', '#')
					->setCellValue('B1', 'Nombres')
					->setCellValue('C1', 'Apellidos')
					->setCellValue('D1', 'E-Mail')
					->setCellValue('E1', 'Status')
					->setCellValue('F1', 'país')
					->setCellValue('G1', 'rol');
		$sheet = $phpExcelObject->getActiveSheet();

		$sheet->setTitle('Usuarios del Sistema');

		$em = $this->getDoctrine()->getEntityManager();
		$users = $this->entityToArray($em);

		$header ='A1:G1';

		$sheet->getStyle($header)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00ffff00');

		$style = array(
			'font' => array('bold' => true,),
			'alignment' => array('horizontal' => \PHPExcel_Style_Alignment::HORIZONTAL_CENTER,),
		);
		$sheet->getStyle($header)->applyFromArray($style);

		$sheet->fromArray($users, ' ', 'A2');

		for ($col = ord('a'); $col <= ord('h'); $col++) {
			$sheet->getColumnDimension(chr($col))->setAutoSize(true);
		}


		$sheet2 = new \PHPExcel_Worksheet($phpExcelObject, 'Totales');
		$phpExcelObject->addSheet($sheet2, 1);
		$sheet2->setTitle('Totales');


		// Set active sheet index to the first sheet, so Excel opens this as the first sheet
		$phpExcelObject->setActiveSheetIndex(0);

		// create the writer
		$writer = $this->get('phpexcel')->createWriter($phpExcelObject, 'Excel2007');
		// create the response
		$response = $this->get('phpexcel')->createStreamedResponse($writer);
		// adding headers

		$today = date('d_m_y_i_s');
		$dispositionHeader = $response->headers->makeDisposition(
			ResponseHeaderBag::DISPOSITION_ATTACHMENT,
			'usuarios'.'_'.$today.'.xlsx'
		);
		$response->headers->set('Content-Type', 'text/vnd.ms-excel; charset=utf-8');
		$response->headers->set('Pragma', 'public');
		$response->headers->set('Cache-Control', 'maxage=1');
		$response->headers->set('Content-Disposition', $dispositionHeader);

		return $response;

	}


	private function entityToArray(EntityManagerInterface $em) {

		$users = $em->getRepository( 'AppBundle:User' )->findAll();

		$data = array();

		foreach($users as $index => $user) {
			$data[ $index ] = $user->toArray();
		}

		return $data;
	}

	private function renderResponse($status,$message,$em,$product,$method) {

		$dataArray = array();

		if ($status) {

			if ($method == 'POST') {
				$dataArray['items'] = $products = $this->entityToArray( $em );
			} else {
				$dataArray['item'] = $product->toArray();
			}

			$dataArray['status'] = $status;
			$dataArray['message'] = $message;

			return new JsonResponse( $dataArray, 200 );
		} else {
			return $this->redirectToRoute( 'config_error', array( 'error-id' => 0 ) );
		}

	}


	private function settingPDFEnvironment($pdf){
		// set document information
		$pdf->SetKeywords( 'Tecnología,Usuarios' );


		// set default header data
		$pdf->SetHeaderData( 'portfolio/thumbnails/tech_trends.jpg', PDF_HEADER_LOGO_WIDTH, "Universidad Tecnológica", 'Siempre a la vanguardia');

		// set header and footer fonts
		$pdf->setHeaderFont( Array( PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN ) );
		$pdf->setFooterFont( Array( PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA ) );

		// set default monospaced font
		$pdf->SetDefaultMonospacedFont( PDF_FONT_MONOSPACED );

		// set margins
		$pdf->SetMargins( PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT );
		$pdf->SetHeaderMargin( PDF_MARGIN_HEADER );
		$pdf->SetFooterMargin( PDF_MARGIN_FOOTER );

		// set auto page breaks
		$pdf->SetAutoPageBreak( true, PDF_MARGIN_BOTTOM );

		// set image scale factor
		$pdf->setImageScale( PDF_IMAGE_SCALE_RATIO );

		$lg                    = Array();
		$lg['a_meta_charset']  = 'UTF-8';
		$lg['a_meta_language'] = 'es';

// set some language-dependent strings (optional)
		$pdf->setLanguageArray( $lg );

		// set font
		$pdf->SetFont( 'helvetica', 'B', 14 );

	}



	/**
	 * Create a user delete form.
	 *
	 * @param User $user The User entity
	 *
	 * @return \Symfony\Component\Form\Form The form
	 */
	private function createDeleteForm(User $user)
	{
		return $this->createFormBuilder()
		            ->setAction($this->get('router')->generate('user_delete', array('id' => $user->getUserId()?$user->getUserId():0 )))
		            ->setMethod('DELETE')
		            ->getForm();
	}

	private function renderIf() {
		if ($this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) {
			return true;
		} else {
			return false;
		}

	}


}
