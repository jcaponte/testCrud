<?php

/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 13/05/2017
 */

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class DefaultController extends Controller
{

	/**
	 * @Route("/", name="homepage")
	 * @param Request $request
	 * @return \Symfony\Component\HttpFoundation\Response $response
	 */
	public function indexAction(Request $request)
	{

		if ($this->getUser() ) {
			return $this->redirectToRoute('user_list');
		}

			$helper = $this->get('security.authentication_utils');
      return $this->render('default/index.html.twig',[
        'last_username' => $helper->getLastUsername(),
        'error' => $helper->getLastAuthenticationError()
      ]);
	}

	/**
	 * @Route("/login_check", name="login_check")
	 */
	public function loginCheckAction()
	{

	}


}