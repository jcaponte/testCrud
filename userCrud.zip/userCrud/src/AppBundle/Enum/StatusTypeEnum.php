<?php
/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 14/08/2017
 * Time: 09:54 PM
 */

namespace AppBundle\Enum;


class StatusTypeEnum {

	const TYPE_ACTIVE    = "Activo";
	const TYPE_INACTIVE = "Inactivo";

	/** @var array mapping to  */
	protected static $status = [
		self::TYPE_ACTIVE    => 'Activo',
		self::TYPE_INACTIVE => 'Inactivo'
	];

	/**
	 * @param  string $internalType
	 * @return string
	 */
	public static function getStatus($internalType)
	{
		if (!isset(static::$status[$internalType])) {
			return "Unknown type ($internalType)";
		}

		return static::$status[$internalType];
	}

	/**
	 * @return array<string>
	 */
	public static function getAllStatus()
	{
		return [
			self::TYPE_ACTIVE,
			self::TYPE_INACTIVE
		];
	}


}