<?php
/**
 * Created by PhpStorm.
 * User: Juan Carlos
 * Date: 19/05/2017
 * Time: 01:08 PM
 */

namespace tests\AppBundle\Entity;


class Test extends \PHPUnit_Framework_TestCase {

}
