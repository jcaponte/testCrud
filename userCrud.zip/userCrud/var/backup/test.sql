-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-08-2017 a las 06:15:01
-- Versión del servidor: 5.7.11
-- Versión de PHP: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `test`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `country`
--

CREATE TABLE `country` (
  `country_id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `phone_prefix` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `country`
--

INSERT INTO `country` (`country_id`, `name`, `phone_prefix`) VALUES
(1, 'Guatemala', '502'),
(2, 'Venezuela', '058'),
(3, 'Argentina', '056');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(64) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(72) NOT NULL,
  `user_role_id` int(11) DEFAULT NULL,
  `status` enum('ACTIVO','INACTIVO') NOT NULL DEFAULT 'ACTIVO',
  `country_id` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `email`, `password`, `user_role_id`, `status`, `country_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(11, 'TEST', 'Admin', 'admin@test.com', '$2a$06$nZkUNMKbdP6AlX/A5/XpIO1T5.xu2dS0ct27SwDHyQOglhXd4rjm2', 1, 'ACTIVO', 1, 11, 11, '2013-06-18 06:03:06', '2017-08-15 04:19:49'),
(12, 'TEST', 'TEST', 'test@gmail.com', '$2a$06$nZkUNMKbdP6AlX/A5/XpIO1T5.xu2dS0ct27SwDHyQOglhXd4rjm2', 1, 'ACTIVO', 1, 11, NULL, '2017-05-21 23:16:45', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_role`
--

CREATE TABLE `user_role` (
  `user_role_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` varchar(512) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `user_role`
--

INSERT INTO `user_role` (`user_role_id`, `name`, `description`, `active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Administrador', 'Full Access', 1, NULL, NULL, '2016-11-17 09:01:00', '2017-08-05 09:43:23'),
(2, 'Autor', 'Sólo puede crear nuevas publicaciones', 1, 11, NULL, '2017-08-15 03:08:28', NULL),
(3, 'Suscriptor', 'Puede sólo mirar', 1, 11, NULL, '2017-08-15 03:51:20', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_role_module_permission`
--

CREATE TABLE `user_role_module_permission` (
  `user_role_module_permission_id` int(11) NOT NULL,
  `user_role_id` int(11) NOT NULL,
  `module_id` int(11) DEFAULT NULL,
  `view_module` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `read_permission` tinyint(1) NOT NULL DEFAULT '0',
  `write_permission` tinyint(1) NOT NULL DEFAULT '0',
  `edit_permission` tinyint(1) NOT NULL DEFAULT '0',
  `delete_permission` tinyint(1) NOT NULL DEFAULT '0',
  `main_module` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `user_role_module_permission`
--

INSERT INTO `user_role_module_permission` (`user_role_module_permission_id`, `user_role_id`, `module_id`, `view_module`, `read_permission`, `write_permission`, `edit_permission`, `delete_permission`, `main_module`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(3, 1, 3, 1, 1, 1, 1, 1, 0, NULL, NULL, NULL, '2017-05-21 20:02:14'),
(11, 1, 10, 1, 1, 1, 1, 1, 0, NULL, NULL, '2016-12-07 16:16:23', '2017-05-21 14:01:12'),
(12, 1, 11, 1, 1, 1, 1, 1, 0, NULL, NULL, '2016-12-07 16:16:33', '2017-05-21 14:01:18'),
(36, 1, 23, 1, 1, 1, 1, 1, 1, NULL, NULL, '2017-08-05 09:43:43', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `user_role_id_fk01_idx` (`user_role_id`);

--
-- Indices de la tabla `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`user_role_id`),
  ADD KEY `fk_user_id05_idx` (`created_by`),
  ADD KEY `fk_user_id06_idx` (`updated_by`);

--
-- Indices de la tabla `user_role_module_permission`
--
ALTER TABLE `user_role_module_permission`
  ADD PRIMARY KEY (`user_role_module_permission_id`),
  ADD KEY `user_role_id` (`user_role_id`),
  ADD KEY `module_id` (`module_id`),
  ADD KEY `fk_user77_idx` (`created_by`),
  ADD KEY `fk_user_id08_idx` (`updated_by`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `country`
--
ALTER TABLE `country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de la tabla `user_role`
--
ALTER TABLE `user_role`
  MODIFY `user_role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `user_role_module_permission`
--
ALTER TABLE `user_role_module_permission`
  MODIFY `user_role_module_permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_country_id02` FOREIGN KEY (`country_id`) REFERENCES `country` (`country_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_role_id01` FOREIGN KEY (`user_role_id`) REFERENCES `user_role` (`user_role_id`) ON DELETE SET NULL ON UPDATE NO ACTION;

--
-- Filtros para la tabla `user_role`
--
ALTER TABLE `user_role`
  ADD CONSTRAINT `fk_user_id05` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_id06` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `user_role_module_permission`
--
ALTER TABLE `user_role_module_permission`
  ADD CONSTRAINT `fk_module_id04` FOREIGN KEY (`module_id`) REFERENCES `module_catalog` (`module_catalog_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_id07` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_id08` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_role_id04` FOREIGN KEY (`user_role_id`) REFERENCES `user_role` (`user_role_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
